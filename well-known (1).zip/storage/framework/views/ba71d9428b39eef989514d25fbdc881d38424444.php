<footer class="footer">
    <div class="d-md-flex justify-content-center justify-content-md-between">
        <span class="text-center text-md-left d-block d-md-inline-block" style="font-size: 14px;">
            Copyright Christ the King nursery and primary school © <?php echo e(date('Y')); ?>. All rights reserved.
        </span>
      <span class="float-none float-md-right d-block mt-1 mt-md-0 text-center" style="font-size: 14px; color: #161176 ;">Developed By Mosh <i class="far fa-heart text-danger"></i></span>
    </div>
  </footer>
<?php /**PATH C:\Users\Administrator\Desktop\christ-the-king\resources\views/layouts/footer.blade.php ENDPATH**/ ?>